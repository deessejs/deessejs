import Image, { type ImageProps } from "next/image";

/**
 * MDX image wrapper. Replaces the default `<img>` rendered by MDX so cover
 * images and inline figures go through next/image optimization (responsive
 * sizes, lazy loading, format selection).
 *
 * Falls back to intrinsic dimensions when the author omits width/height —
 * matches MDX's default `<img>` behavior so authors don't need to size images.
 *
 * SPEC 15.4 — cover images optimized via next/image.
 */
export function MdxImage({
  alt,
  ...props
}: ImageProps) {
  // next/image requires width/height (or fill). When the MDX author didn't
  // provide them, fall back to a sane default. The author can override by
  // writing `<MdxImage src="..." width={800} height={450} />` in MDX.
  const width = props.width ?? 1200;
  const height = props.height ?? 630;

  return (
    <Image
      alt={alt ?? ""}
      sizes="(min-width: 768px) 768px, 100vw"
      {...props}
      width={width}
      height={height}
    />
  );
}