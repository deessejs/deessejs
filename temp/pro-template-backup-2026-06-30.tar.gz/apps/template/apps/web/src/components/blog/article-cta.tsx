import Link from "next/link";

import { Button } from "@deessejs/ui/components/button";

import {
  ArrowRightIcon,
  BookOpenIcon,
} from "@/components/icons";

/**
 * ArticleCta — closing call-to-action block at the bottom of every article
 * (blog post + changelog release).
 *
 * Sits below the "Related reading" section. The glow + centered headline
 * pattern is reusable — the buyer can rebrand the headline and CTAs to
 * match their product.
 *
 * Default copy points to the buyer's home and a hypothetical /docs route.
 * Buyers who don't have a docs route should change the `href` here or
 * remove this component from the post + release page templates.
 *
 * Mirror of apps/web/src/components/blog/article-cta.tsx — copy adapted
 * from DeesseJS-specific ("Get DeesseJS") to buyer-generic ("Get started").
 */
export function ArticleCta() {
  return (
    <section className="relative mt-16 overflow-hidden rounded-xl border border-border/40 bg-card/30 px-6 py-10 text-center sm:px-10 sm:py-12">
      <div
        aria-hidden
        className="pointer-events-none absolute left-1/2 top-1/2 -z-10 h-[200px] w-[400px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-foreground/10 opacity-40 blur-[80px]"
      />

      <h2 className="text-balance text-xl font-semibold tracking-tight text-foreground sm:text-2xl">
        Ready to ship faster?
      </h2>
      <p className="mx-auto mt-2 max-w-lg text-pretty text-sm text-muted-foreground">
        Edit this component to match your product positioning. The layout,
        glow, and CTA structure are reusable — only the copy is yours.
      </p>

      <div className="mt-5 flex flex-wrap items-center justify-center gap-2">
        <Button
          size="sm"
          className="h-9 gap-1.5 rounded-full px-5 text-sm font-semibold shadow-sm transition-transform hover:scale-105"
          nativeButton={false}
          render={<Link href="/" />}
        >
          Get started
          <ArrowRightIcon className="size-3.5" />
        </Button>
        <Button
          size="sm"
          variant="outline"
          className="h-9 gap-1.5 rounded-full px-5 text-sm font-medium shadow-sm backdrop-blur-md"
          nativeButton={false}
          render={<Link href="/docs" />}
        >
          <BookOpenIcon className="size-3.5" />
          Read the docs
        </Button>
      </div>
    </section>
  );
}