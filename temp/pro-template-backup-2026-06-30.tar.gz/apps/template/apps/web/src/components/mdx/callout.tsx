import type { ReactNode } from "react";

import { cn } from "@deessejs/ui/lib/utils";

/**
 * Callout component for use inside blog MDX. Authored as `<Callout>` or
 * `<Callout type="warn">` (info / warn / danger). Renders an inline container
 * with semantic-token colors so dark mode flips automatically.
 *
 * Wired in via `<MDXContent components={{ Callout }} />` in the post page —
 * not via mdx-components.tsx because cc uses mdx-bundler, not @next/mdx.
 *
 * SPEC 15 — blog feature for the buyer template. Lives in the blog's delete
 * surface area (tests/delete-blog.sh).
 */
export function Callout({
  type = "info",
  children,
}: {
  type?: "info" | "warn" | "danger";
  children: ReactNode;
}) {
  const styles: Record<NonNullable<typeof type>, string> = {
    info: "border-border bg-accent/40 text-foreground",
    warn: "border-amber-500/40 bg-amber-500/10 text-foreground",
    danger: "border-destructive/40 bg-destructive/10 text-foreground",
  };

  const label: Record<NonNullable<typeof type>, string> = {
    info: "Note",
    warn: "Warning",
    danger: "Danger",
  };

  return (
    <aside
      data-slot="callout"
      data-type={type}
      className={cn(
        "not-prose my-6 rounded-lg border px-4 py-3 text-sm",
        styles[type],
      )}
      role="note"
      aria-label={label[type]}
    >
      <div className="mb-1 font-medium text-xs uppercase tracking-wide opacity-70">
        {label[type]}
      </div>
      <div className="prose prose-sm max-w-none [&>:first-child]:mt-0 [&>:last-child]:mb-0">
        {children}
      </div>
    </aside>
  );
}