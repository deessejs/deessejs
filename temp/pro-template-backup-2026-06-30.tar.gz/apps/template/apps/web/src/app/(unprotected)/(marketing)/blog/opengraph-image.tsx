import { ImageResponse } from "next/og";

export const alt = "DeesseJS Blog";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

/**
 * Open Graph image for /blog. Generated at build time via next/og.
 *
 * Tokens are hardcoded hex values (mirror of the oklch literals in
 * packages/ui/src/styles/globals.css) because next/og's underlying Satori
 * renderer does not support `oklch()` — only hex / rgb.
 *
 * SPEC 15.5 — blog SEO. SPEC 15 — blog feature for the buyer template.
 */
export default async function Image() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          padding: 80,
          background: "#ffffff",
          color: "#252525",
          fontFamily: "system-ui, sans-serif",
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 16,
            fontSize: 28,
            color: "#6b6b6b",
          }}
        >
          <div
            style={{
              width: 16,
              height: 16,
              borderRadius: 4,
              background: "#353535",
            }}
          />
          DeesseJS
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div
            style={{
              fontSize: 96,
              fontWeight: 700,
              letterSpacing: -2,
              lineHeight: 1.05,
            }}
          >
            Blog
          </div>
          <div
            style={{
              fontSize: 32,
              color: "#6b6b6b",
              maxWidth: 900,
              lineHeight: 1.3,
            }}
          >
            Engineering notes on the modular SaaS template.
          </div>
        </div>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            fontSize: 24,
            color: "#6b6b6b",
            borderTop: "1px solid #ebebeb",
            paddingTop: 32,
          }}
        >
          <span>deessejs.com</span>
          <span style={{ display: "flex", gap: 16 }}>
            <span>Architecture</span>
            <span>·</span>
            <span>Delete tests</span>
            <span>·</span>
            <span>Modular contract</span>
          </span>
        </div>
      </div>
    ),
    { ...size },
  );
}