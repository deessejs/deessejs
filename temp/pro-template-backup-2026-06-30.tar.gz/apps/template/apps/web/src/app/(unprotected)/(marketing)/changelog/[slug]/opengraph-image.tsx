import { ImageResponse } from "next/og";

import { getReleaseBySlug } from "@/lib/blog/releases";

export const size = { width: 1200, height: 630 };
export const contentType = "image/png";
export const alt = "Release notes";

/**
 * Per-release Open Graph image. Generated at build time via next/og.
 * Tokens hardcoded in hex (Satori doesn't support oklch).
 */
export default async function Image({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const release = getReleaseBySlug(slug);

  const title = release
    ? `v${release.version} — ${release.title}`
    : "Changelog";
  const description = release?.description ?? "Public release notes.";

  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          padding: 80,
          background: "#ffffff",
          color: "#252525",
          fontFamily: "system-ui, sans-serif",
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 16,
            fontSize: 24,
            color: "#6b6b6b",
          }}
        >
          <div
            style={{
              width: 12,
              height: 12,
              borderRadius: 9999,
              background: "#353535",
            }}
          />
          Changelog
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
          <div
            style={{
              fontSize: 72,
              fontWeight: 700,
              lineHeight: 1.1,
              letterSpacing: -1.5,
              maxWidth: 1000,
            }}
          >
            {title}
          </div>
          <div
            style={{
              fontSize: 28,
              color: "#6b6b6b",
              maxWidth: 950,
              lineHeight: 1.4,
            }}
          >
            {description}
          </div>
        </div>
        <div
          style={{
            display: "flex",
            gap: 12,
            fontSize: 22,
            color: "#6b6b6b",
            borderTop: "1px solid #ebebeb",
            paddingTop: 28,
          }}
        >
          /changelog
        </div>
      </div>
    ),
    { ...size },
  );
}