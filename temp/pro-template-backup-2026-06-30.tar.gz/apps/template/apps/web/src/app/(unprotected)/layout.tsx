import Link from "next/link"
import type { PropsWithChildren } from "react"

import { Button } from "@deessejs/ui/components/button"
import { cn } from "@deessejs/ui/lib/utils"

/**
 * Layout for the entire "unprotected" surface — public pages that don't
 * require auth. Wraps both (marketing) and (auth) subtrees.
 *
 * Provides the shared chrome:
 *   - Sticky slim top nav (DeesseJS brand + marketing links + Log in / Sign up)
 *
 * Sub-layouts ((marketing)/layout.tsx and (auth)/layout.tsx) only add
 * their own specialized structure (footer, 2-column form shell, etc.)
 * — no need to repeat the top nav.
 *
 * The inner wrapper is `flex flex-1 flex-col` so child layouts can use
 * `flex-1` to fill the remaining vertical space.
 *
 * NOTE on the Blog link: it lives in the top nav because blog is a
 * public marketing surface (per (marketing)/layout.tsx JSDoc). If the
 * buyer runs `pnpm test:delete:blog`, the blog route folder is removed
 * but the link here becomes a 404 — buyers who delete the blog must
 * also remove this nav link manually. See tests/delete-blog.sh.
 */
const MARKETING_NAV = [
  { href: "/blog", label: "Blog" },
  { href: "/changelog", label: "Changelog" },
] as const

export default function UnprotectedLayout({ children }: PropsWithChildren) {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b border-border bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <nav
          aria-label="Primary"
          className="mx-auto flex h-14 max-w-screen-2xl items-center justify-between px-4 sm:px-6"
        >
          <div className="flex items-center gap-6">
            <Link
              href="/"
              className="text-base font-semibold tracking-tight text-foreground"
            >
              DeesseJS
            </Link>
            <ul className="hidden items-center gap-1 sm:flex">
              {MARKETING_NAV.map((item) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    className={cn(
                      "rounded-md px-3 py-1.5 text-sm text-muted-foreground transition-colors",
                      "hover:bg-accent hover:text-foreground",
                    )}
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div className="flex items-center gap-1.5 sm:gap-2">
            <Button
              render={<Link href="/login" />}
              variant="ghost"
              nativeButton={false}
              className="hidden sm:inline-flex"
            >
              Log in
            </Button>
            <Button
              render={<Link href="/signup" />}
              variant="default"
              nativeButton={false}
            >
              Sign up
            </Button>
          </div>
        </nav>
      </header>
      <div className="flex flex-1 flex-col">{children}</div>
    </div>
  )
}
