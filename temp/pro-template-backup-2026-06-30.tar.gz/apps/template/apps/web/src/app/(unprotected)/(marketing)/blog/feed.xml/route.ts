import { buildBlogFeed } from "@/lib/blog/feed";
import { getAllPosts } from "@/lib/blog/posts";

/**
 * RSS 2.0 feed for the blog.
 *
 * Per spec 15.6 + 15.16: RSS is the ONLY subscription mechanism — no in-app
 * fan-out, no email digest. Zero vendor lock-in.
 *
 * Site origin is env-driven (NEXT_PUBLIC_SITE_URL) so the buyer can deploy
 * on any domain without editing this file.
 */
export const dynamic = "force-static";

function getSiteOrigin(): string {
  // We read from a public env var so the feed works under static rendering.
  // Defaults to localhost for local dev.
  return (
    process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000"
  ).replace(/\/$/, "");
}

export function GET() {
  const xml = buildBlogFeed(getAllPosts(), getSiteOrigin());
  return new Response(xml, {
    headers: {
      "content-type": "application/rss+xml; charset=utf-8",
      "cache-control": "public, max-age=3600, s-maxage=3600",
    },
  });
}