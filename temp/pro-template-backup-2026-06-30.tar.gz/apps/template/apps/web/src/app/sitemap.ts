import type { MetadataRoute } from "next";
import { allPosts, allReleases } from "content-collections";

/**
 * Root sitemap. Includes static routes, blog index, every post, every tag
 * page, the changelog index, and every release page. Generated at build
 * time by Next.js.
 *
 * Mirror of apps/web/src/app/sitemap.ts (adapted for buyer template).
 * SPEC 15.7 — sitemap (blog + tags + changelog).
 */
export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date();

  // Top-level surfaces.
  const topLevel: MetadataRoute.Sitemap[number][] = [
    {
      url: "/blog",
      lastModified: now,
      changeFrequency: "weekly",
      priority: 0.9,
    },
    {
      url: "/changelog",
      lastModified: now,
      changeFrequency: "weekly",
      priority: 0.8,
    },
  ];

  // Every blog post.
  const postEntries: MetadataRoute.Sitemap = allPosts.map((post) => ({
    url: post.url,
    lastModified: new Date(post.updated ?? post.date),
    changeFrequency: "monthly",
    priority: 0.7,
    ...(post.cover ? { images: [post.cover] } : {}),
  }));

  // Every release.
  const releaseEntries: MetadataRoute.Sitemap = allReleases.map(
    (release) => ({
      url: release.url,
      lastModified: new Date(release.date),
      changeFrequency: "yearly",
      priority: 0.6,
      ...(release.cover ? { images: [release.cover] } : {}),
    }),
  );

  // Unique tags.
  const tagSet = new Set<string>();
  for (const post of allPosts) {
    for (const tag of post.tags) tagSet.add(tag);
  }
  const tagEntries: MetadataRoute.Sitemap = Array.from(tagSet).map((tag) => ({
    url: `/blog/tag/${encodeURIComponent(tag)}`,
    lastModified: now,
    changeFrequency: "weekly",
    priority: 0.5,
  }));

  return [...topLevel, ...postEntries, ...releaseEntries, ...tagEntries];
}