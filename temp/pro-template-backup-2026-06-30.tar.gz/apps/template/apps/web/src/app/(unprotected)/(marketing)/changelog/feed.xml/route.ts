import { buildChangelogFeed } from "@/lib/blog/feed";
import { getAllReleases } from "@/lib/blog/releases";

/**
 * RSS 2.0 feed for the changelog.
 *
 * Per spec 15.16: the ONLY subscription mechanism for release notes.
 * Zero vendor lock-in — no in-app fan-out, no email digest.
 */
export const dynamic = "force-static";

function getSiteOrigin(): string {
  return (
    process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000"
  ).replace(/\/$/, "");
}

export function GET() {
  const xml = buildChangelogFeed(getAllReleases(), getSiteOrigin());
  return new Response(xml, {
    headers: {
      "content-type": "application/rss+xml; charset=utf-8",
      "cache-control": "public, max-age=3600, s-maxage=3600",
    },
  });
}