import { ImageResponse } from "next/og";

export const size = { width: 1200, height: 630 };
export const contentType = "image/png";
export const alt = "Changelog";

/**
 * Open Graph image for /changelog. Generated at build time via next/og.
 *
 * Tokens hardcoded in hex (mirror of packages/ui oklch values) — next/og
 * doesn't support oklch() (Satori limitation).
 *
 * SPEC 15.5 — blog SEO + changelog SEO.
 */
export default async function Image() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          padding: 80,
          background: "#ffffff",
          color: "#252525",
          fontFamily: "system-ui, sans-serif",
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 16,
            fontSize: 24,
            color: "#6b6b6b",
          }}
        >
          <div
            style={{
              width: 12,
              height: 12,
              borderRadius: 9999,
              background: "#353535",
            }}
          />
          Changelog
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div
            style={{
              fontSize: 96,
              fontWeight: 700,
              letterSpacing: -2,
              lineHeight: 1.05,
            }}
          >
            Changelog
          </div>
          <div
            style={{
              fontSize: 32,
              color: "#6b6b6b",
              maxWidth: 900,
              lineHeight: 1.3,
            }}
          >
            Public release notes. Subscribe via RSS.
          </div>
        </div>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            fontSize: 22,
            color: "#6b6b6b",
            borderTop: "1px solid #ebebeb",
            paddingTop: 32,
          }}
        >
          <span>/changelog</span>
          <span style={{ display: "flex", gap: 16 }}>
            <span>Added</span>
            <span>·</span>
            <span>Changed</span>
            <span>·</span>
            <span>Fixed</span>
          </span>
        </div>
      </div>
    ),
    { ...size },
  );
}