import type { Metadata } from "next";
import type { ReactNode } from "react";

/**
 * Blog layout — applies the .prose typography chrome to all routes under
 * /blog (index, [slug], tag/[tag]). Inherits the (unprotected) top nav and
 * the (marketing) footer via the parent route group chain.
 *
 * `metadataBase` resolves OG/Twitter image URLs that omit the host. The
 * buyer overrides this at deploy time via `NEXT_PUBLIC_SITE_URL`.
 *
 * SPEC 15 — blog feature for the buyer template. Lives in the blog's
 * delete-test surface area (tests/delete-blog.sh).
 */
export const metadata: Metadata = {
  metadataBase: new URL(
    process.env.NEXT_PUBLIC_SITE_URL ?? "https://example.com",
  ),
};

export default function BlogLayout({ children }: { children: ReactNode }) {
  return (
    <div className="mx-auto w-full max-w-3xl px-4 py-12 sm:px-6">
      {children}
    </div>
  );
}