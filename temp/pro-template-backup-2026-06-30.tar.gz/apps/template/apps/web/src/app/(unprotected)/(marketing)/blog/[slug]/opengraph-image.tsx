import { ImageResponse } from "next/og";
import { allPosts } from "content-collections";

export const alt = "DeesseJS Blog post";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

/**
 * Per-post Open Graph image. Reads the post title + description from the
 * content-collections-generated `allPosts` array.
 *
 * Tokens are hardcoded hex values (mirror of the oklch literals in
 * packages/ui/src/styles/globals.css) because next/og's underlying Satori
 * renderer does not support `oklch()`.
 *
 * SPEC 15.5 — blog SEO (per-post OG). SPEC 15 — blog feature for the buyer
 * template.
 */
export default async function Image({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const post = allPosts.find((p) => p.slug === slug);

  const title = post?.title ?? "DeesseJS Blog";
  const description =
    post?.description ?? "Engineering notes on the modular SaaS template.";
  const tags = post?.tags.join(" · ") ?? "";

  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          padding: 80,
          background: "#ffffff",
          color: "#252525",
          fontFamily: "system-ui, sans-serif",
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 16,
            fontSize: 24,
            color: "#6b6b6b",
          }}
        >
          <div
            style={{
              width: 12,
              height: 12,
              borderRadius: 3,
              background: "#353535",
            }}
          />
          DeesseJS Blog
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
          <div
            style={{
              fontSize: 76,
              fontWeight: 700,
              letterSpacing: -1.5,
              lineHeight: 1.05,
              maxWidth: 1000,
            }}
          >
            {title}
          </div>
          <div
            style={{
              fontSize: 28,
              color: "#6b6b6b",
              maxWidth: 950,
              lineHeight: 1.4,
            }}
          >
            {description}
          </div>
        </div>
        {tags ? (
          <div
            style={{
              display: "flex",
              gap: 12,
              fontSize: 22,
              color: "#6b6b6b",
              borderTop: "1px solid #ebebeb",
              paddingTop: 28,
            }}
          >
            {tags}
          </div>
        ) : null}
      </div>
    ),
    { ...size },
  );
}