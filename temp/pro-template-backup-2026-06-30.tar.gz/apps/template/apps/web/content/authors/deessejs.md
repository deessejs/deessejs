---
handle: deessejs
name: DeesseJS Team
avatar: https://avatars.githubusercontent.com/u/222233001?v=4
bio: The team behind the DeesseJS modular SaaS template.
---

The DeesseJS team writes about architecture decisions, modular contracts,
and the delete-test pattern that powers the template's no-feature-creep
guarantee.