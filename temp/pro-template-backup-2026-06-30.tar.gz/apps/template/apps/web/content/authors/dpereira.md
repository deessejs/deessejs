---
handle: dpereira
name: David Pereira
avatar: https://github.com/codewizdave.png
bio: Founder of DeesseJS. Building the SaaS template he wished he had three projects ago.
---

David writes about architecture decisions, modular contracts, and the
delete-test pattern that powers the template's no-feature-creep guarantee.