
export default [
  {
    "handle": "deessejs",
    "name": "DeesseJS Team",
    "avatar": "https://avatars.githubusercontent.com/u/222233001?v=4",
    "bio": "The team behind the DeesseJS modular SaaS template.",
    "content": "The DeesseJS team writes about architecture decisions, modular contracts,\r\nand the delete-test pattern that powers the template's no-feature-creep\r\nguarantee.",
    "_meta": {
      "filePath": "deessejs.md",
      "fileName": "deessejs.md",
      "directory": ".",
      "extension": "md",
      "path": "deessejs"
    }
  },
  {
    "handle": "dpereira",
    "name": "David Pereira",
    "avatar": "https://github.com/codewizdave.png",
    "bio": "Founder of DeesseJS. Building the SaaS template he wished he had three projects ago.",
    "content": "David writes about architecture decisions, modular contracts, and the\ndelete-test pattern that powers the template's no-feature-creep guarantee.",
    "_meta": {
      "filePath": "dpereira.md",
      "fileName": "dpereira.md",
      "directory": ".",
      "extension": "md",
      "path": "dpereira"
    }
  }
]