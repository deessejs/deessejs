import configuration from "../../content-collections.ts";
import { GetTypeByName } from "@content-collections/core";

export type Author = GetTypeByName<typeof configuration, "authors">;
export declare const allAuthors: Array<Author>;

export type Post = GetTypeByName<typeof configuration, "posts">;
export declare const allPosts: Array<Post>;

export type Release = GetTypeByName<typeof configuration, "releases">;
export declare const allReleases: Array<Release>;

export {};
