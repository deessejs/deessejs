
export default [
  {
    "title": "0.1.0 — Initial public beta",
    "description": "First public release of DeesseJS. Auth, billing, jobs, storage, notifications, API — every surface your agents need, wired from day one.",
    "version": "0.1.0",
    "date": "2026-06-26",
    "categories": [
      "added"
    ],
    "relatedPosts": [
      "agents-are-first-class-developers",
      "why-content-collections"
    ],
    "content": "# DeesseJS 0.1.0 — Initial public beta\n\nThe first public release of DeesseJS is out. The marketing site you're\nreading is built on the template itself — same engine, same components,\nsame patterns you'd ship in your own product.\n\n## What's in 0.1.0\n\n### Added\n\n- **Auth (Better Auth 1.6.19)** — email, OAuth, passkeys, magic links, 2FA\n- **Database (Drizzle + Neon)** — type-safe Postgres with migrations + seeds\n- **Backend API (Hono + oRPC)** — end-to-end typed RPC without codegen\n- **Email (Resend + react-email v6)** — transactional templates + preview app\n- **Design system (@workspace/ui)** — shadcn/ui on Base UI, Geist-aligned tokens\n- **Documentation (Fumadocs 16)** — full-text search, MDX, code blocks\n- **Blog + changelog (content-collections)** — see the [related post](/blog/why-content-collections)\n\n### Notes\n\nThis is the **founding release**. Founder pricing ($99, $249, $499) is\ncapped at 50 founders and closes July 31, 2026.\n\nIf you find a bug, open an issue. If an agent breaks the build, that's a\nfeature request — we want to know.",
    "_meta": {
      "filePath": "0.1.0-initial-public-beta.mdx",
      "fileName": "0.1.0-initial-public-beta.mdx",
      "directory": ".",
      "extension": "mdx",
      "path": "0.1.0-initial-public-beta"
    },
    "slug": "0.1.0-initial-public-beta",
    "url": "/changelog/0.1.0-initial-public-beta",
    "mdxCode": "var Component=(()=>{var u=Object.create;var r=Object.defineProperty;var g=Object.getOwnPropertyDescriptor;var p=Object.getOwnPropertyNames;var m=Object.getPrototypeOf,f=Object.prototype.hasOwnProperty;var y=(t,e)=>()=>(e||t((e={exports:{}}).exports,e),e.exports),b=(t,e)=>{for(var i in e)r(t,i,{get:e[i],enumerable:!0})},l=(t,e,i,o)=>{if(e&&typeof e==\"object\"||typeof e==\"function\")for(let s of p(e))!f.call(t,s)&&s!==i&&r(t,s,{get:()=>e[s],enumerable:!(o=g(e,s))||o.enumerable});return t};var w=(t,e,i)=>(i=t!=null?u(m(t)):{},l(e||!t||!t.__esModule?r(i,\"default\",{value:t,enumerable:!0}):i,t)),k=t=>l(r({},\"__esModule\",{value:!0}),t);var c=y((_,a)=>{a.exports=_jsx_runtime});var x={};b(x,{default:()=>d});var n=w(c());function h(t){let e={a:\"a\",h1:\"h1\",h2:\"h2\",h3:\"h3\",li:\"li\",p:\"p\",strong:\"strong\",ul:\"ul\",...t.components};return(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(e.h1,{children:\"DeesseJS 0.1.0 \\u2014 Initial public beta\"}),`\n`,(0,n.jsx)(e.p,{children:`The first public release of DeesseJS is out. The marketing site you're\nreading is built on the template itself \\u2014 same engine, same components,\nsame patterns you'd ship in your own product.`}),`\n`,(0,n.jsx)(e.h2,{children:\"What's in 0.1.0\"}),`\n`,(0,n.jsx)(e.h3,{children:\"Added\"}),`\n`,(0,n.jsxs)(e.ul,{children:[`\n`,(0,n.jsxs)(e.li,{children:[(0,n.jsx)(e.strong,{children:\"Auth (Better Auth 1.6.19)\"}),\" \\u2014 email, OAuth, passkeys, magic links, 2FA\"]}),`\n`,(0,n.jsxs)(e.li,{children:[(0,n.jsx)(e.strong,{children:\"Database (Drizzle + Neon)\"}),\" \\u2014 type-safe Postgres with migrations + seeds\"]}),`\n`,(0,n.jsxs)(e.li,{children:[(0,n.jsx)(e.strong,{children:\"Backend API (Hono + oRPC)\"}),\" \\u2014 end-to-end typed RPC without codegen\"]}),`\n`,(0,n.jsxs)(e.li,{children:[(0,n.jsx)(e.strong,{children:\"Email (Resend + react-email v6)\"}),\" \\u2014 transactional templates + preview app\"]}),`\n`,(0,n.jsxs)(e.li,{children:[(0,n.jsx)(e.strong,{children:\"Design system (@workspace/ui)\"}),\" \\u2014 shadcn/ui on Base UI, Geist-aligned tokens\"]}),`\n`,(0,n.jsxs)(e.li,{children:[(0,n.jsx)(e.strong,{children:\"Documentation (Fumadocs 16)\"}),\" \\u2014 full-text search, MDX, code blocks\"]}),`\n`,(0,n.jsxs)(e.li,{children:[(0,n.jsx)(e.strong,{children:\"Blog + changelog (content-collections)\"}),\" \\u2014 see the \",(0,n.jsx)(e.a,{href:\"/blog/why-content-collections\",children:\"related post\"})]}),`\n`]}),`\n`,(0,n.jsx)(e.h3,{children:\"Notes\"}),`\n`,(0,n.jsxs)(e.p,{children:[\"This is the \",(0,n.jsx)(e.strong,{children:\"founding release\"}),`. Founder pricing ($99, $249, $499) is\ncapped at 50 founders and closes July 31, 2026.`]}),`\n`,(0,n.jsx)(e.p,{children:`If you find a bug, open an issue. If an agent breaks the build, that's a\nfeature request \\u2014 we want to know.`})]})}function d(t={}){let{wrapper:e}=t.components||{};return e?(0,n.jsx)(e,{...t,children:(0,n.jsx)(h,{...t})}):h(t)}return k(x);})();\n;return Component;"
  }
]