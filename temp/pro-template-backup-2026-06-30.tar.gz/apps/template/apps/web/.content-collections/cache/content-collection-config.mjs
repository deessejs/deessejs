// content-collections.ts
import { defineCollection, defineConfig } from "@content-collections/core";
import { compileMDX } from "@content-collections/mdx";
import rehypeShiki from "@shikijs/rehype";
import { z } from "zod";
import readingTime from "reading-time";
var authors = defineCollection({
  name: "authors",
  directory: "content/authors",
  include: "*.md",
  schema: z.object({
    handle: z.string().min(1).max(60),
    name: z.string().min(1).max(120),
    avatar: z.string().optional(),
    bio: z.string().optional(),
    // Explicit `content` declaration required by cc 0.15+ — the implicit
    // addition was deprecated. Holds the raw markdown body.
    content: z.string()
  })
});
var posts = defineCollection({
  name: "posts",
  directory: "content/posts",
  include: "*.mdx",
  // Default parser: "frontmatter" — extracts frontmatter + raw body, which
  // compileMDX needs to bundle the MDX into a JS module string.
  schema: z.object({
    title: z.string().min(1).max(120),
    description: z.string().min(1).max(280),
    date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
    updated: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
    tags: z.array(z.string()).default([]),
    author: z.string().min(1),
    draft: z.boolean().default(false),
    cover: z.string().optional(),
    scheduled: z.string().datetime().optional(),
    // Explicit `content` declaration required by cc 0.15+ — holds the raw
    // MDX body used by compileMDX and reading-time.
    content: z.string()
  }),
  transform: async (post, context) => {
    if (post.draft && process.env.NODE_ENV === "production") {
      return context.skip("document is a draft");
    }
    if (post.scheduled && new Date(post.scheduled) > /* @__PURE__ */ new Date()) {
      return context.skip(`scheduled for ${post.scheduled}`);
    }
    const author = context.documents(authors).find(
      (a) => a.handle === post.author
    );
    if (!author) {
      throw new Error(
        `Post "${post.title}" references unknown author "${post.author}". Add content/authors/${post.author}.md or fix the frontmatter.`
      );
    }
    const slug = post._meta.filePath.replace(/^.*\//, "").replace(/\.mdx$/, "");
    const mdxCode = await compileMDX(context, post, {
      rehypePlugins: [
        [
          rehypeShiki,
          {
            themes: { light: "github-light", dark: "github-dark" },
            defaultColor: false
            // emit both themes; CSS controls which shows
          }
        ]
      ]
    });
    const stats = readingTime(post.content);
    return {
      ...post,
      slug,
      url: `/blog/${slug}`,
      readingTime: Math.max(1, Math.round(stats.minutes)),
      author,
      mdxCode
    };
  }
});
var releases = defineCollection({
  name: "releases",
  directory: "content/releases",
  include: "*.mdx",
  schema: z.object({
    title: z.string().min(1).max(120),
    description: z.string().min(1).max(280),
    version: z.string().regex(/^\d+\.\d+\.\d+$/, "semver"),
    date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
    categories: z.array(
      z.enum([
        "added",
        "changed",
        "fixed",
        "removed",
        "deprecated",
        "security"
      ])
    ).default([]),
    cover: z.string().optional(),
    relatedPosts: z.array(z.string()).default([]),
    content: z.string()
  }),
  transform: async (release, context) => {
    const slug = release._meta.filePath.replace(/^.*\//, "").replace(/\.mdx$/, "");
    const mdxCode = await compileMDX(context, release, {
      rehypePlugins: [
        [
          rehypeShiki,
          {
            themes: { light: "github-light", dark: "github-dark" },
            defaultColor: false
          }
        ]
      ]
    });
    return {
      ...release,
      slug,
      url: `/changelog/${slug}`,
      mdxCode
    };
  }
});
var content_collections_default = defineConfig({
  content: [authors, posts, releases]
});
export {
  content_collections_default as default
};
