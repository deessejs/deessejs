#!/usr/bin/env bash
# ============================================================================
# Blog + changelog delete-test — proves the modular contract (spec 20.1, 23.25).
#
# Snapshot the working tree, remove every file in the blog+changelog delete-
# test surface area, run the production build, restore. PASS = the rest of
# the buyer template still builds without blog + changelog.
#
# Run from the monorepo root:
#   pnpm --filter deessejs-template-root test:delete:blog
#
# SPEC 15 — blog feature for the buyer template. Slice v2 (matches the
# apps/web surface: blog + changelog + related + adjacent + RSS + sitemap).
# ============================================================================
set -euo pipefail

# This file lives at apps/template/apps/web/tests/delete-blog.sh. The
# monorepo root is 5 levels up.
ROOT="$(cd "$(dirname "$0")/../../../../.." && pwd)"
cd "$ROOT"

WEB="apps/template/apps/web"
TEMPLATE_ROOT="apps/template"

STASH_LABEL="blog-delete-test-$(date +%s)"

echo "[blog-delete] Snapshotting working state..."
git stash push --keep-index --include-untracked -m "$STASH_LABEL" >/dev/null

cleanup() {
  local exit_code=$?
  echo "[blog-delete] Restoring working state..."
  git checkout -- . >/dev/null 2>&1 || true
  git stash pop >/dev/null 2>&1 || true
  if [ $exit_code -eq 0 ]; then
    echo "[blog-delete] PASS"
  else
    echo "[blog-delete] FAIL (exit $exit_code)"
  fi
  exit $exit_code
}
trap cleanup EXIT

echo "[blog-delete] Removing blog + changelog files..."
PATHS=(
  # Engine config
  "$WEB/content-collections.ts"
  # Content sources
  "$WEB/content"
  # Routes
  "$WEB/src/app/sitemap.ts"
  "$WEB/src/app/(unprotected)/(marketing)/blog"
  "$WEB/src/app/(unprotected)/(marketing)/changelog"
  # Components
  "$WEB/src/components/blog"
  "$WEB/src/components/icons.tsx"
  # Lib helpers
  "$WEB/src/lib/blog"
)

# Reverting config files (deps + wrappers)
CONFIG_PATHS=(
  "$WEB/package.json"
  "$WEB/next.config.ts"
  "$WEB/tsconfig.json"
  "$WEB/.gitignore"
)

for p in "${PATHS[@]}"; do
  rm -rf "$p"
done

echo "[blog-delete] Reverting config files..."
git checkout -- "${CONFIG_PATHS[@]}"

echo "[blog-delete] Reinstalling to drop content-collections deps..."
pnpm install --filter @deessejs/template-web >/dev/null

echo "[blog-delete] Running build..."
pnpm --filter @deessejs/template-web build >/dev/null

echo "[blog-delete] Build succeeded without the blog + changelog."