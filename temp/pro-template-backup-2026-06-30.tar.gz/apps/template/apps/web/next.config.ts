import { withContentCollections } from "@content-collections/next";
import type { NextConfig } from "next";
import path from "node:path";

const nextConfig: NextConfig = {
  // Per shadcn-ui monorepo research: workspace packages are symlinked
  // into apps/web/node_modules via pnpm. Without `transpilePackages`,
  // Next.js treats them as external deps and skips transpilation —
  // TSX sources fail to resolve. We transpile all 4 internal packages.
  // See `.claude/agent-memory/tech-lead/reference-shadcn-monorepo.md` § 3
  transpilePackages: [
    "@deessejs/ui",
    "@deessejs/api",
    "@deessejs/auth",
    "@deessejs/database",
  ],
  // The buyer template lives inside a nested pnpm workspace
  // (`apps/template/`). Turbopack scans up from this Next.js project and
  // finds two `pnpm-workspace.yaml` files (the outer monorepo + this
  // nested workspace). Pin `turbopack.root` to this nested workspace so
  // Turbopack scopes its scans correctly and silences the warning.
  // `pnpm --filter` runs scripts with cwd set to the package root, so
  // `process.cwd()` resolves to `apps/template/apps/web/` here. Going up
  // two levels lands on `apps/template/` (the nested workspace root).
  turbopack: {
    root: path.join(process.cwd(), "..", ".."),
  },
};

// withContentCollections runs cc at build time and wires the generated
// `.content-collections/` directory into the TS path alias defined in
// tsconfig.json. Per spec 15.1 — single wrapper, single config file.
// See content-collections.ts and tests/delete-blog.sh for the delete-test
// surface area.
export default withContentCollections(nextConfig);